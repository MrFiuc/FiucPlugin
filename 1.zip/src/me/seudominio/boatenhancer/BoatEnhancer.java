package me.seudominio.boatenhancer;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.vehicle.VehicleMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public class BoatEnhancer extends JavaPlugin implements Listener {

    private double speedMultiplier;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        speedMultiplier = getConfig().getDouble("speed-multiplier", 1.5);

        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("BoatEnhancer ativado com multiplicador: " + speedMultiplier);
    }

    @Override
    public void onDisable() {
        getLogger().info("BoatEnhancer desativado.");
    }

    @EventHandler
    public void onBoatMove(VehicleMoveEvent event) {
        Entity vehicle = event.getVehicle();

        if (!(vehicle instanceof Boat)) return;

        Vector vel = vehicle.getVelocity();
        vel.multiply(speedMultiplier);
        vehicle.setVelocity(vel);

        // Subida automática
        Block blockInFront = vehicle.getLocation().add(vel.getX(), 0, vel.getZ()).getBlock();
        Block blockAbove = blockInFront.getRelative(0, 1, 0);

        if (blockInFront.getType().isSolid() && blockAbove.getType().isAir()) {
            vehicle.setVelocity(new Vector(vel.getX(), 0.6, vel.getZ()));
        }
    }

    // Comando para alterar o multiplicador
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("boatenhancer.admin")) {
            sender.sendMessage("§cVocê não tem permissão.");
            return true;
        }

        if (args.length != 1) {
            sender.sendMessage("§eUso: /boatenhancer <velocidade>");
            return true;
        }

        try {
            double newSpeed = Double.parseDouble(args[0]);
            if (newSpeed <= 0) throw new NumberFormatException();

            speedMultiplier = newSpeed;
            getConfig().set("speed-multiplier", newSpeed);
            saveConfig();

            sender.sendMessage("§aMultiplicador de velocidade atualizado para: " + newSpeed);
        } catch (NumberFormatException e) {
            sender.sendMessage("§cValor inválido. Use um número positivo.");
        }

        return true;
    }
}
